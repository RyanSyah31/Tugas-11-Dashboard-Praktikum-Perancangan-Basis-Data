<?php

        $sql_cek = "SELECT * FROM barang";
        $query_cek = mysqli_query($koneksi, $sql_cek);
		$data_cek = mysqli_fetch_array($query_cek,MYSQLI_BOTH);
		{

		
?>



<?php
		}
	$sql = $koneksi->query("SELECT count(nama_barang) as lokal from barang");
	while ($data= $sql->fetch_assoc()) {

		$lokal=$data['lokal'];
	}
?>



<?php
		
	$sql = $koneksi->query("SELECT count(nama_barang) as produk from barang");
	while ($data= $sql->fetch_assoc()) {
		
		$produk=$data['produk'];
	}
?>

<div class="row">
	<div class="col-lg-3 col-6">
		<!-- small box -->
		<div class="small-box bg-primary">
			<div class="inner">
				<h3>
					<?php echo $lokal;  ?>
				</h3>

				<p>Jumlah Pelanggan</p>
			</div>
			<div class="icon">
				<i class="ion ion-person-add"></i>
			</div>
			<a href="index.php?page=data-pelanggan" class="small-box-footer">Selengkapnya
				<i class="fas fa-arrow-circle-right"></i>
			</a>
		</div>
	</div>
	