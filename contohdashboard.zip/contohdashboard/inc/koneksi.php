<?php
$koneksi = new mysqli ("localhost","root","","ryansyah_311810264");
?>

<!-- end -->